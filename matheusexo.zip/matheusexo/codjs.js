let resp = window.document.getElementById('saida')
function acao1(){
    resp.innerHTML += '<p> o felipe'
}
function acao2(){
    resp.innerHTML += '<p> engravidou'
}
function acao3(){
    resp.innerHTML += '<p> a velma'
}
function acao4(){
    resp.innerHTML += '<p> e n quer pagar pensão'
}
function calcular() {
    let n1 = Number(window.prompt('digite um numero:'))
    let res = document.querySelector('section#res')

    res.innerHTML = `<p> 0 dobro de ${n1} é ${n1 * 2} e a metade é ${n1 / 2} </p>`
}
function somar(){
    let n1 = Number(window.prompt('digite um número: '))
    let n2 = Number(window.prompt('digite outro número: '))
    soma = n1+n2 
    let res = document.querySelector('section#res')
    res.innerHTML = `<p> A soma entre ${n1} e ${n2} é igual a ${soma} </p>`
}